# AQUASENSE — Smart Industrial Wastewater Management System

**Tagline:** *"Intelligence for Every Drop."*  
**Team:** THE THINKERS  
**Vision:** *"Building a smarter and more responsible future through intelligent water monitoring and sustainable technology."*

## Scientific & Regulatory Disclosure
pH and turbidity measurements do not identify every industrial pollutant. Basic filtration cannot guarantee removal of dissolved chemicals, heavy metals or all hazardous substances. The prototype is not certified for drinking water or industrial discharge. Actual treatment requires pollutant-specific analysis, suitable treatment processes and applicable regulatory approval.

## Run Locally
1. Extract the ZIP archive into a folder.
2. Open a terminal inside the extracted project folder (`aquasense-starter`).
3. Install dependencies and start the dev server:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL shown in the terminal (typically `http://localhost:5173`).

## Deploy to Vercel or GitHub Pages
- **Vercel:** Push this folder to a GitHub repository, import into Vercel (`vite` preset, build command `npm run build`, output directory `dist`), and deploy.
- **GitHub Pages:** Set `base` in `vite.config.js` to `'/YOUR_REPO_NAME/'`, run `npm run build`, and publish the `dist` folder.
