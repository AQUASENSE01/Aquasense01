import React, { useState, useMemo } from "react";
import {
  Activity,
  Droplets,
  Cpu,
  ShieldCheck,
  Sliders,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Star,
  Plus,
  Trash2,
  Search,
  Lock,
  Unlock,
  Database,
  Layers,
  FlaskConical,
  Building2,
  GraduationCap,
  Microscope,
  Sparkles,
  FileText,
  Mail,
  Phone,
  MapPin,
  Menu,
  X,
  RefreshCw,
  Send,
  Info,
  Check,
  ChevronDown,
  ChevronUp,
  ExternalLink
} from "lucide-react";

/**
 * AQUASENSE — Smart Industrial Wastewater Management System
 * Parent Team: THE THINKERS
 * Tagline: "Intelligence for Every Drop."
 * Vision: "Building a smarter and more responsible future through intelligent water monitoring and sustainable technology."
 */

const INITIAL_PRODUCTS = [
  {
    id: "prod-edu",
    name: "Educational Prototype",
    priceLabel: "₹2,499",
    priceNumeric: 2499,
    type: "Illustrative Price",
    badge: "Starter Kit",
    description:
      "Compact benchtop demonstration kit for schools and introductory engineering labs to explore sensor telemetry, threshold logic, and basic gravity filtration.",
    specs: [
      "Arduino UNO R3 compatible controller board",
      "Analog pH probe + optical turbidity sensor + flow meter",
      "Micro servo actuator with miniature diverter channel",
      "3-stage visible filtration column (Screening, Sand/Gravel, Carbon)",
      "USB serial telemetry monitor & guided lab workbook"
    ],
    limitations:
      "Demonstration hardware only. Not calibrated for industrial compliance or potable water production."
  },
  {
    id: "prod-adv",
    name: "Advanced Demonstration Model",
    priceLabel: "₹4,999",
    priceNumeric: 4999,
    type: "Illustrative Price",
    badge: "Most Requested",
    description:
      "Expanded multi-stage test rig featuring real-time threshold tuning, LED status diagnostics, and a 6-stage demonstration treatment sequence.",
    specs: [
      "Arduino UNO controller with multi-channel sensor shield",
      "Calibrated pH, turbidity (NTU), and volumetric flow sensors",
      "High-torque servo diverter valve + tri-color status LEDs",
      "6-stage modular treatment sequence (up to final quality check)",
      "Live web telemetry simulator & experiment log export"
    ],
    limitations:
      "Intended for laboratory and institutional demonstration. Does not remove dissolved heavy metals or all trace organics."
  },
  {
    id: "prod-inst",
    name: "Institutional Package",
    priceLabel: "Custom Quote",
    priceNumeric: null,
    type: "Tailored Scope",
    badge: "Research & Labs",
    description:
      "Custom-configured demonstration and research bay package tailored for colleges, incubators, and comparative water-quality studies.",
    specs: [
      "Dual-line comparison channels (Bypass vs. Treatment Path)",
      "Custom sensor mounting manifold & calibration kit",
      "Faculty/lab curriculum & experimentation documentation",
      "Optional data-logging & future IoT gateway readiness",
      "Dedicated technical onboarding by THE THINKERS"
    ],
    limitations:
      "Requires site and lab review; not certified for industrial effluent discharge or drinking water."
  }
];

const INITIAL_INQUIRIES = [
  {
    id: "AQS-2026-1042",
    fullName: "Dr. Kavita Nair",
    email: "k.nair@deccan-envlab.edu.in",
    phone: "+91 98201 55410",
    organization: "Deccan Environmental Engineering Lab",
    location: "Pune, Maharashtra",
    interestedProduct: "Advanced Demonstration Model",
    quantity: 2,
    budgetRange: "₹5,000 – ₹15,000",
    message:
      "Looking for an interactive sensor-and-diverter demonstration rig for undergraduate environmental instrumentation lab sessions.",
    status: "Pending",
    submittedAt: "2026-11-18 10:24 IST"
  },
  {
    id: "AQS-2026-1039",
    fullName: "Rohan Deshmukh",
    email: "rohan.d@kaveri-textiles-demo.in",
    phone: "+91 97654 22190",
    organization: "Kaveri Process Pilot Unit",
    location: "Surat, Gujarat",
    interestedProduct: "Institutional Package",
    quantity: 1,
    budgetRange: "₹15,000+ (Custom)",
    message:
      "Interested in evaluating conceptual diversion logic alongside our internal lab chemical testing protocols.",
    status: "Processed",
    submittedAt: "2026-11-14 16:45 IST"
  }
];

const INITIAL_REVIEWS = [
  {
    id: "rev-1",
    name: "Ananya Verma (Demo Entry)",
    organization: "Campus Innovation Showcase — Demo",
    rating: 5,
    feedback:
      "Clear visual connection between pH/turbidity readings, servo diversion, and the six filtration steps. Helpful for explaining automation logic to students.",
    suggestions: "Add a downloadable sample calibration sheet for turbidity sensors.",
    date: "2026-11-10",
    status: "Approved",
    isDemo: true
  },
  {
    id: "rev-2",
    name: "Siddharth Kulkarni (Demo Entry)",
    organization: "Water Systems Study Group — Demo",
    rating: 4,
    feedback:
      "Appreciated the transparent explanation of what basic filtration and pH/turbidity sensors can and cannot verify.",
    suggestions: "Include wiring pinout diagrams for Arduino UNO sensor inputs.",
    date: "2026-11-12",
    status: "Pending",
    isDemo: true
  }
];

const TREATMENT_STAGES = [
  {
    step: 1,
    title: "Screening",
    subtitle: "Coarse & Fine Physical Separation",
    summary:
      "Removes larger suspended solids, fibers, grit, and debris using mesh screens before water reaches downstream channels.",
    detail:
      "Prevents mechanical clogging in demonstration tubing and protects sedimentation and media beds from oversized particulates."
  },
  {
    step: 2,
    title: "Sedimentation",
    subtitle: "Gravity Settling Basin",
    summary:
      "Slows flow velocity in a settling zone so denser suspended particles settle toward the bottom under gravity.",
    detail:
      "Reduces incoming turbidity load prior to granular media filtration during demonstration runs."
  },
  {
    step: 3,
    title: "Sand and Gravel Filtration",
    subtitle: "Graded Granular Media Bed",
    summary:
      "Passes water through graded gravel and sand layers to trap finer suspended particles and flocs.",
    detail:
      "Strains remaining particulates while maintaining controlled hydraulic flow across the demonstration column."
  },
  {
    step: 4,
    title: "Activated Carbon Filtration",
    subtitle: "Adsorption Polishing Stage",
    summary:
      "Uses high-surface-area activated carbon to adsorb certain organic compounds, odor-causing molecules, and color.",
    detail:
      "Demonstrates surface adsorption principles while respecting finite media saturation limits."
  },
  {
    step: 5,
    title: "Disinfection",
    subtitle: "Microbial Control Demonstration",
    summary:
      "Represents targeted microbial reduction/disinfection conditioning in the treatment sequence.",
    detail:
      "In real-world systems, disinfection efficacy depends on contact time, turbidity clarity, dose, and water chemistry."
  },
  {
    step: 6,
    title: "Final Quality Checking",
    subtitle: "Post-Process Verification Stage",
    summary:
      "Evaluates treated stream indicators before deciding on further treatment, appropriate reuse, or compliant disposal.",
    detail:
      "Highlights why verification and regulatory lab testing remain essential before any reuse or release."
  }
];

const FLOW_NODES = [
  {
    id: "inlet",
    label: "Wastewater Inlet",
    short: "Source Entry",
    description:
      "Incoming wastewater enters the prototype test line from a simulated or controlled industrial/lab source.",
    technical: "Accepts metered test stream with baseline logging of flow rate and initial sample conditions."
  },
  {
    id: "collection",
    label: "Collection Tank",
    short: "Buffer & Equalization",
    description:
      "Buffers flow surges and stabilizes entry conditions so sensors can read representative values.",
    technical: "Smooths short-term hydraulic fluctuations prior to sensor measurement."
  },
  {
    id: "monitoring",
    label: "Sensor Monitoring",
    short: "pH, Turbidity & Flow",
    description:
      "Measures acidity/alkalinity (pH), optical cloudiness (turbidity in NTU), and volumetric flow rate.",
    technical: "Analog and pulse signals are conditioned for microcontroller sampling."
  },
  {
    id: "arduino",
    label: "Arduino Processing",
    short: "Threshold Logic",
    description:
      "Arduino UNO compares live sensor readings against programmed safe operating thresholds.",
    technical: "Evaluates pH window (e.g., 6.5–8.5), turbidity ceiling, and flow continuity every scan cycle."
  },
  {
    id: "diversion",
    label: "Automatic Diversion",
    short: "Servo & Diverter Valve",
    description:
      "Actuates the servo motor and diverter valve while updating LED status indicators based on control rules.",
    technical: "Routes out-of-range streams to hold/containment or diversion path; routes within-band streams to treatment."
  },
  {
    id: "treatment",
    label: "Demonstration Treatment",
    short: "6-Stage Sequence",
    description:
      "Runs water through Screening, Sedimentation, Sand & Gravel, Activated Carbon, and Disinfection stages.",
    technical: "Demonstrates physical straining, gravity settling, adsorption, and conditioning in sequence."
  },
  {
    id: "testing",
    label: "Final Water Quality Testing",
    short: "Post-Treatment Check",
    description:
      "Checks post-stage water indicators and flags need for comprehensive laboratory analysis.",
    technical: "Verifies observable parameters while noting that dissolved toxins/heavy metals require specialized lab tests."
  },
  {
    id: "outcome",
    label: "Further Treatment / Appropriate Reuse / Compliant Disposal",
    short: "Controlled Disposition",
    description:
      "Directs water toward additional treatment, approved non-potable reuse, or legally compliant disposal.",
    technical: "Final disposition always requires engineering validation and applicable environmental permits."
  }
];

const FAQ_ITEMS = [
  {
    q: "Can AQUASENSE detect every industrial pollutant or heavy metal?",
    a: "No. pH, turbidity, and flow sensors provide valuable operational indicators, but they do not identify dissolved chemical toxins, heavy metals, solvents, or specific industrial pathogens. Comprehensive laboratory testing is required for pollutant-specific verification."
  },
  {
    q: "Is the AQUASENSE prototype certified for drinking water or industrial discharge?",
    a: "No. AQUASENSE is an educational, demonstration, and prototyping platform developed by THE THINKERS. It is not certified for potable water supply or direct industrial effluent discharge, which require engineered treatment systems and regulatory approval."
  },
  {
    q: "Are the prices listed on the Product Showcase final commercial prices?",
    a: "No. The Educational Prototype (₹2,499), Advanced Demonstration Model (₹4,999), and Institutional Package (Custom Quote) are proposed illustrative prices for demonstration and planning purposes, not confirmed commercial prices."
  },
  {
    q: "How do inquiries and feedback work in this version?",
    a: "When no live backend is connected, the platform runs in a clearly labelled Demo Mode storing session/state data locally in your browser. Connecting Supabase enables persistent database storage and Row Level Security (RLS)."
  }
];

const SUPABASE_SQL_SCHEMA = `-- AQUASENSE Database Schema & Row Level Security (PostgreSQL / Supabase)

create table if not exists public.products (
  id text primary key,
  name text not null,
  price_label text not null,
  price_numeric integer,
  price_note text not null default 'Illustrative Price',
  badge text,
  description text not null,
  specs jsonb not null default '[]'::jsonb,
  limitations text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.inquiries (
  id uuid primary key default gen_random_uuid(),
  reference_code text unique not null,
  full_name text not null,
  email text not null,
  phone text not null,
  organization text not null,
  location text not null,
  interested_product text not null,
  quantity integer not null check (quantity > 0),
  budget_range text not null,
  message text not null,
  status text not null default 'Pending' check (status in ('Pending', 'Reviewed', 'Processed')),
  created_at timestamptz not null default now()
);

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  reviewer_name text not null,
  organization text,
  rating integer not null check (rating between 1 and 5),
  feedback_text text not null,
  suggestions text,
  status text not null default 'Pending' check (status in ('Pending', 'Approved', 'Rejected')),
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- Enable Row Level Security
alter table public.products enable row level security;
alter table public.inquiries enable row level security;
alter table public.feedback enable row level security;
alter table public.site_settings enable row level security;

-- Public read access for products and approved feedback only
create policy "Public read products" on public.products for select using (true);
create policy "Public read approved feedback" on public.feedback for select using (status = 'Approved');
create policy "Public read site settings" on public.site_settings for select using (true);

-- Public insert for inquiries and new pending feedback
create policy "Public submit inquiry" on public.inquiries
  for insert with check (status = 'Pending');

create policy "Public submit feedback" on public.feedback
  for insert with check (status = 'Pending');

-- Authenticated admin policies (replace with role/claim check in production)
create policy "Admin manage inquiries" on public.inquiries
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Admin manage feedback" on public.feedback
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Admin manage products" on public.products
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Admin manage settings" on public.site_settings
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');`;

function AquaSenseLogo({ compact = false }) {
  return (
    <div className="flex items-center gap-3 select-none">
      <div className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-cyan-400/30 bg-gradient-to-br from-cyan-500/20 via-sky-500/10 to-emerald-400/15 shadow-[0_0_24px_rgba(34,211,238,0.18)]">
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          <path
            d="M12 2.75C12 2.75 5.25 10.1 5.25 14.85C5.25 18.5779 8.27208 21.6 12 21.6C15.7279 21.6 18.75 18.5779 18.75 14.85C18.75 10.1 12 2.75 12 2.75Z"
            stroke="url(#aquaGrad)"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="12" cy="14.8" r="2.3" stroke="#34d399" strokeWidth="1.5" />
          <path
            d="M8.5 14.8H9.7M14.3 14.8H15.5"
            stroke="#22d3ee"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          <defs>
            <linearGradient id="aquaGrad" x1="6" y1="4" x2="18" y2="21" gradientUnits="userSpaceOnUse">
              <stop stopColor="#22d3ee" />
              <stop offset="1" stopColor="#34d399" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div className="leading-tight">
        <div className="flex items-center gap-1.5">
          <span className="text-base font-bold tracking-[0.2em] text-white">
            AQUA<span className="text-cyan-400">SENSE</span>
          </span>
        </div>
        {!compact && (
          <p className="text-[10px] font-medium tracking-[0.14em] text-slate-400 uppercase">
            By THE THINKERS
          </p>
        )}
      </div>
    </div>
  );
}

function HeroSystemDiagram({ ph, turbidity, flowRate, isDiverted }) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-cyan-400/20 bg-[#081326]/90 p-5 shadow-[0_20px_60px_rgba(2,8,20,0.75)] backdrop-blur-xl">
      <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-cyan-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-emerald-400/10 blur-3xl" />

      <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-semibold tracking-wider text-cyan-300 uppercase">
            Prototype Telemetry & Routing Schematic
          </span>
        </div>
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border ${
            isDiverted
              ? "border-amber-400/40 bg-amber-500/15 text-amber-300"
              : "border-emerald-400/40 bg-emerald-500/15 text-emerald-300"
          }`}
        >
          <span className={`h-1.5 w-1.5 rounded-full ${isDiverted ? "bg-amber-400" : "bg-emerald-400"}`} />
          {isDiverted ? "Diverter Active: Hold / Inspect" : "Nominal Band: Treatment Path"}
        </span>
      </div>

      {/* Live Digital Readout Strip */}
      <div className="mb-4 grid grid-cols-3 gap-2.5">
        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400">pH Sensor</p>
          <p className="mt-0.5 text-lg font-bold text-white tabular-nums">{ph.toFixed(1)}</p>
          <p className="text-[10px] text-cyan-300/80">Target: 6.5–8.5</p>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400">Turbidity</p>
          <p className="mt-0.5 text-lg font-bold text-white tabular-nums">{turbidity} NTU</p>
          <p className="text-[10px] text-cyan-300/80">Limit: &le; 25 NTU</p>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400">Flow Rate</p>
          <p className="mt-0.5 text-lg font-bold text-white tabular-nums">{flowRate.toFixed(1)} L/m</p>
          <p className="text-[10px] text-emerald-300/80">Demo Loop</p>
        </div>
      </div>

      {/* SVG Process Schematic */}
      <div className="rounded-xl border border-white/10 bg-[#050c19] p-3">
        <svg viewBox="0 0 640 250" className="h-auto w-full" role="img" aria-label="AQUASENSE wastewater monitoring, Arduino diversion, and 6-stage filtration schematic">
          <defs>
            <linearGradient id="pipeNormal" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#34d399" />
            </linearGradient>
            <linearGradient id="pipeAlert" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#ef4444" />
            </linearGradient>
          </defs>

          {/* Inlet to Monitoring Unit */}
          <rect x="14" y="34" width="118" height="58" rx="10" fill="#0d1d38" stroke="#22d3ee" strokeOpacity="0.45" />
          <text x="73" y="57" textAnchor="middle" fill="#e2e8f0" fontSize="11" fontWeight="600">1. Wastewater Inlet</text>
          <text x="73" y="74" textAnchor="middle" fill="#94a3b8" fontSize="9.5">Monitoring Unit</text>

          <line x1="132" y1="63" x2="168" y2="63" stroke="url(#pipeNormal)" strokeWidth="2.5" strokeDasharray="5 4" />
          <polygon points="168,58 177,63 168,68" fill="#22d3ee" />

          {/* Sensor & Arduino UNO Block */}
          <rect x="178" y="24" width="146" height="78" rx="10" fill="#0d1d38" stroke="#38bdf8" strokeOpacity="0.55" />
          <text x="251" y="45" textAnchor="middle" fill="#38bdf8" fontSize="10.5" fontWeight="700">2. Sensors + Arduino UNO</text>
          <text x="251" y="62" textAnchor="middle" fill="#cbd5e1" fontSize="9">pH • Turbidity • Flow</text>
          <text x="251" y="77" textAnchor="middle" fill="#34d399" fontSize="9">Threshold Logic &amp; LEDs</text>
          <circle cx="204" cy="91" r="4" fill={isDiverted ? "#ef4444" : "#10b981"} />
          <text x="214" y="94" fill="#94a3b8" fontSize="8.5">{isDiverted ? "Alert State" : "Nominal State"}</text>

          <line x1="324" y1="63" x2="360" y2="63" stroke="url(#pipeNormal)" strokeWidth="2.5" strokeDasharray="5 4" />
          <polygon points="360,58 369,63 360,68" fill="#22d3ee" />

          {/* Automated Servo Diverter */}
          <rect x="370" y="34" width="122" height="58" rx="10" fill="#0d1d38" stroke={isDiverted ? "#f59e0b" : "#34d399"} strokeOpacity="0.7" />
          <text x="431" y="57" textAnchor="middle" fill="#f8fafc" fontSize="10.5" fontWeight="600">3. Servo Diverter</text>
          <text x="431" y="74" textAnchor="middle" fill={isDiverted ? "#fcd34d" : "#6ee7b7"} fontSize="9.5">
            {isDiverted ? "Diverted to Hold" : "Routed to Treatment"}
          </text>

          {/* Branch down to Diversion Hold */}
          <line x1="431" y1="92" x2="431" y2="126" stroke={isDiverted ? "url(#pipeAlert)" : "#475569"} strokeWidth="2.5" strokeDasharray={isDiverted ? "5 4" : "3 3"} />
          <polygon points="426,126 436,126 431,135" fill={isDiverted ? "#f59e0b" : "#64748b"} />

          <rect x="356" y="136" width="150" height="44" rx="9" fill="#171421" stroke="#f59e0b" strokeOpacity={isDiverted ? "0.75" : "0.25"} />
          <text x="431" y="155" textAnchor="middle" fill="#fde68a" fontSize="10" fontWeight="600">Diversion / Hold Line</text>
          <text x="431" y="169" textAnchor="middle" fill="#94a3b8" fontSize="8.5">Out-of-range sample routing</text>

          {/* Branch right to 6-Stage Filtration */}
          <line x1="492" y1="63" x2="516" y2="63" stroke={!isDiverted ? "url(#pipeNormal)" : "#475569"} strokeWidth="2.5" strokeDasharray={!isDiverted ? "5 4" : "3 3"} />
          <polygon points="516,58 525,63 516,68" fill={!isDiverted ? "#34d399" : "#64748b"} />

          <rect x="506" y="114" width="122" height="118" rx="10" fill="#091b29" stroke="#34d399" strokeOpacity="0.45" />
          <text x="567" y="132" textAnchor="middle" fill="#6ee7b7" fontSize="9.5" fontWeight="700">4. 6-Stage Demo</text>
          <text x="567" y="146" textAnchor="middle" fill="#cbd5e1" fontSize="8">1. Screening</text>
          <text x="567" y="159" textAnchor="middle" fill="#cbd5e1" fontSize="8">2. Sedimentation</text>
          <text x="567" y="172" textAnchor="middle" fill="#cbd5e1" fontSize="8">3. Sand &amp; Gravel</text>
          <text x="567" y="185" textAnchor="middle" fill="#cbd5e1" fontSize="8">4. Activated Carbon</text>
          <text x="567" y="198" textAnchor="middle" fill="#cbd5e1" fontSize="8">5. Disinfection</text>
          <text x="567" y="211" textAnchor="middle" fill="#22d3ee" fontSize="8" fontWeight="600">6. Final Quality Check</text>

          {/* Bottom note */}
          <rect x="14" y="194" width="326" height="38" rx="8" fill="#091324" stroke="white" strokeOpacity="0.08" />
          <text x="24" y="210" fill="#94a3b8" fontSize="8.5">Prototype Scope: Demonstration &amp; telemetry visualization only.</text>
          <text x="24" y="223" fill="#64748b" fontSize="8">Not certified for drinking water or direct industrial discharge.</text>
        </svg>
      </div>
    </div>
  );
}

export default function App() {
  const [activeNav, setActiveNav] = useState("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Interactive Telemetry Simulator State
  const [ph, setPh] = useState(7.2);
  const [turbidity, setTurbidity] = useState(14);
  const [flowRate, setFlowRate] = useState(4.5);

  // Interactive Technology & Flow State
  const [activeUnitTab, setActiveUnitTab] = useState("unit-a");
  const [selectedStage, setSelectedStage] = useState(TREATMENT_STAGES[0]);
  const [selectedFlowNode, setSelectedFlowNode] = useState(FLOW_NODES[0]);
  const [openFaqIndex, setOpenFaqIndex] = useState(0);

  // Store State (Demo Mode / Local State)
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [inquiries, setInquiries] = useState(INITIAL_INQUIRIES);
  const [reviews, setReviews] = useState(INITIAL_REVIEWS);
  const [contactInfo, setContactInfo] = useState({
    teamName: "THE THINKERS",
    brandName: "AQUASENSE",
    email: "contact@aquasense-demo.example",
    phone: "+91 00000 00000 (Placeholder)",
    location: "India — Demonstration & Prototype Hub"
  });
  const [visionStatement, setVisionStatement] = useState(
    "Building a smarter and more responsible future through intelligent water monitoring and sustainable technology."
  );

  // Inquiry Form State
  const [inquiryForm, setInquiryForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    organization: "",
    location: "",
    interestedProduct: "Educational Prototype",
    quantity: 1,
    budgetRange: "₹2,000 – ₹5,000",
    message: ""
  });
  const [inquiryErrors, setInquiryErrors] = useState({});
  const [isSubmittingInquiry, setIsSubmittingInquiry] = useState(false);
  const [lastSubmittedInquiry, setLastSubmittedInquiry] = useState(null);

  // Review Form State
  const [reviewForm, setReviewForm] = useState({
    name: "",
    organization: "",
    rating: 5,
    feedback: "",
    suggestions: ""
  });
  const [reviewSubmittedMessage, setReviewSubmittedMessage] = useState("");

  // Admin State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminPasscodeInput, setAdminPasscodeInput] = useState("");
  const [adminAuthError, setAdminAuthError] = useState("");
  const [adminTab, setAdminTab] = useState("inquiries");
  const [inquirySearch, setInquirySearch] = useState("");
  const [inquiryStatusFilter, setInquiryStatusFilter] = useState("All");

  // Toast Notification
  const [toast, setToast] = useState(null);

  const showToast = (message, tone = "info") => {
    setToast({ message, tone });
    setTimeout(() => {
      setToast((prev) => (prev && prev.message === message ? null : prev));
    }, 3600);
  };

  const navigateTo = (sectionId) => {
    setActiveNav(sectionId);
    setMobileMenuOpen(false);
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  // Threshold Evaluation for Unit B Logic
  const logicEvaluation = useMemo(() => {
    const phOk = ph >= 6.5 && ph <= 8.5;
    const turbidityOk = turbidity <= 25;
    const flowOk = flowRate >= 1.0 && flowRate <= 10.0;
    const isDiverted = !(phOk && turbidityOk && flowOk);

    const reasons = [];
    if (!phOk) reasons.push(`pH ${ph.toFixed(1)} outside 6.5–8.5 window`);
    if (!turbidityOk) reasons.push(`Turbidity ${turbidity} NTU exceeds 25 NTU threshold`);
    if (!flowOk) reasons.push(`Flow rate ${flowRate.toFixed(1)} L/m outside 1.0–10.0 L/m range`);

    return {
      phOk,
      turbidityOk,
      flowOk,
      isDiverted,
      servoAngle: isDiverted ? "90° (Divert Port)" : "0° (Main Treatment Port)",
      ledState: isDiverted ? "Amber/Red Alert LED Active" : "Green Nominal LED Active",
      reasons
    };
  }, [ph, turbidity, flowRate]);

  // Inquiry Validation & Submission
  const validateInquiry = () => {
    const errs = {};
    if (!inquiryForm.fullName.trim()) errs.fullName = "Full name is required.";
    if (!inquiryForm.email.trim() || !/^\S+@\S+\.\S+$/.test(inquiryForm.email)) {
      errs.email = "Enter a valid email address.";
    }
    if (!inquiryForm.phone.trim() || inquiryForm.phone.trim().length < 7) {
      errs.phone = "Enter a valid phone number.";
    }
    if (!inquiryForm.organization.trim()) errs.organization = "Organization or institution is required.";
    if (!inquiryForm.location.trim()) errs.location = "Location is required.";
    if (!inquiryForm.quantity || Number(inquiryForm.quantity) < 1) {
      errs.quantity = "Quantity must be at least 1.";
    }
    if (!inquiryForm.message.trim() || inquiryForm.message.trim().length < 10) {
      errs.message = "Please include at least 10 characters describing your requirement.";
    }
    setInquiryErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleInquirySubmit = (e) => {
    e.preventDefault();
    if (!validateInquiry()) {
      showToast("Please fix the highlighted form fields.", "error");
      return;
    }

    setIsSubmittingInquiry(true);
    setTimeout(() => {
      const refCode = `AQS-2026-${Math.floor(1050 + Math.random() * 8900)}`;
      const newRecord = {
        id: refCode,
        ...inquiryForm,
        quantity: Number(inquiryForm.quantity),
        status: "Pending",
        submittedAt: new Date().toISOString().replace("T", " ").slice(0, 16) + " UTC (Demo)"
      };
      setInquiries((prev) => [newRecord, ...prev]);
      setLastSubmittedInquiry(newRecord);
      setIsSubmittingInquiry(false);
      setInquiryForm({
        fullName: "",
        email: "",
        phone: "",
        organization: "",
        location: "",
        interestedProduct: "Educational Prototype",
        quantity: 1,
        budgetRange: "₹2,000 – ₹5,000",
        message: ""
      });
      setInquiryErrors({});
      showToast(`Demo inquiry saved locally with reference ${refCode}.`, "success");
    }, 450);
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (!reviewForm.name.trim() || !reviewForm.feedback.trim()) {
      showToast("Please enter your name and feedback.", "error");
      return;
    }
    const created = {
      id: `rev-${Date.now()}`,
      name: reviewForm.name.trim(),
      organization: reviewForm.organization.trim() || "Independent Visitor",
      rating: reviewForm.rating,
      feedback: reviewForm.feedback.trim(),
      suggestions: reviewForm.suggestions.trim() || "None provided",
      date: new Date().toISOString().slice(0, 10),
      status: "Pending",
      isDemo: true
    };
    setReviews((prev) => [created, ...prev]);
    setReviewForm({ name: "", organization: "", rating: 5, feedback: "", suggestions: "" });
    setReviewSubmittedMessage(
      "Submitted in Demo Mode: Your feedback is queued for moderation and will appear publicly once approved in the Admin Control Center."
    );
    showToast("Feedback queued for moderation (Demo Mode).", "success");
  };

  const approvedReviews = useMemo(
    () => reviews.filter((r) => r.status === "Approved"),
    [reviews]
  );

  const avgRating = useMemo(() => {
    if (!reviews.length) return "0.0";
    const sum = reviews.reduce((acc, r) => acc + Number(r.rating || 0), 0);
    return (sum / reviews.length).toFixed(1);
  }, [reviews]);

  const filteredInquiries = useMemo(() => {
    return inquiries.filter((item) => {
      const matchesStatus = inquiryStatusFilter === "All" || item.status === inquiryStatusFilter;
      const q = inquirySearch.toLowerCase();
      const matchesQuery =
        !q ||
        item.id.toLowerCase().includes(q) ||
        item.fullName.toLowerCase().includes(q) ||
        item.organization.toLowerCase().includes(q) ||
        item.interestedProduct.toLowerCase().includes(q);
      return matchesStatus && matchesQuery;
    });
  }, [inquiries, inquirySearch, inquiryStatusFilter]);

  const handleAdminUnlock = (e) => {
    e.preventDefault();
    // Demonstration unlock mode (non-secret local demo gate; production should use Supabase Auth)
    if (adminPasscodeInput.trim().length >= 4) {
      setIsAdminAuthenticated(true);
      setAdminAuthError("");
      setAdminPasscodeInput("");
      showToast("Admin Demo Session unlocked. Connect Supabase Auth for production.", "success");
    } else {
      setAdminAuthError("Enter at least 4 characters to open the local Admin Demo workspace.");
    }
  };

  const updateInquiryStatus = (id, nextStatus) => {
    setInquiries((prev) => prev.map((item) => (item.id === id ? { ...item, status: nextStatus } : item)));
    showToast(`Inquiry ${id} marked as ${nextStatus}.`, "info");
  };

  const deleteInquiry = (id) => {
    if (window.confirm(`Delete inquiry ${id}? This action cannot be undone.`)) {
      setInquiries((prev) => prev.filter((item) => item.id !== id));
      showToast(`Deleted inquiry ${id}.`, "info");
    }
  };

  const updateReviewStatus = (id, nextStatus) => {
    setReviews((prev) => prev.map((r) => (r.id === id ? { ...r, status: nextStatus } : r)));
    showToast(`Review status updated to ${nextStatus}.`, "info");
  };

  const deleteReview = (id) => {
    if (window.confirm("Remove this feedback entry?")) {
      setReviews((prev) => prev.filter((r) => r.id !== id));
      showToast("Feedback entry removed.", "info");
    }
  };

  const updateProductPrice = (id, newLabel) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, priceLabel: newLabel } : p))
    );
    showToast("Illustrative pricing updated in local demo state.", "info");
  };

  const navItems = [
    { id: "home", label: "Home" },
    { id: "technology", label: "Technology" },
    { id: "solutions", label: "Solutions" },
    { id: "applications", label: "Applications" },
    { id: "about", label: "About" },
    { id: "feedback", label: "Feedback" },
    { id: "contact", label: "Contact" }
  ];

  return (
    <div className="min-h-screen bg-[#040b17] text-slate-100 selection:bg-cyan-400/30 selection:text-cyan-100">
      {/* Subtle Ambient Background */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[440px] w-[780px] -translate-x-1/2 rounded-full bg-cyan-500/[0.07] blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[360px] w-[520px] rounded-full bg-emerald-400/[0.05] blur-[120px]" />
      </div>

      {/* Toast Notification */}
      {toast && (
        <div
          role="status"
          className={`fixed bottom-5 right-5 z-50 flex max-w-sm items-center gap-2.5 rounded-xl border px-4 py-3 text-xs font-medium shadow-2xl backdrop-blur-xl ${
            toast.tone === "error"
              ? "border-rose-400/40 bg-rose-950/90 text-rose-200"
              : toast.tone === "success"
              ? "border-emerald-400/40 bg-emerald-950/90 text-emerald-200"
              : "border-cyan-400/40 bg-slate-900/95 text-cyan-100"
          }`}
        >
          <Sparkles className="h-4 w-4 shrink-0" />
          <span>{toast.message}</span>
        </div>
      )}

      {/* Navigation Bar */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#040b17]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={() => navigateTo("home")}
            className="text-left focus:outline-none"
          >
            <AquaSenseLogo />
          </button>

          {/* Desktop Nav */}
          <nav className="hidden items-center gap-5 lg:flex" aria-label="Primary Navigation">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`text-xs font-medium tracking-wide transition ${
                  activeNav === item.id
                    ? "text-cyan-300"
                    : "text-slate-300 hover:text-white"
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              type="button"
              onClick={() => navigateTo("admin")}
              className="text-xs font-medium text-slate-400 hover:text-cyan-300 transition"
            >
              Admin
            </button>
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            <button
              type="button"
              onClick={() => navigateTo("quote")}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-4 py-2 text-xs font-semibold text-slate-950 shadow-[0_0_24px_rgba(34,211,238,0.3)] hover:brightness-110 transition"
            >
              Get a Quote
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Mobile Hamburger */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            className="rounded-lg border border-white/10 p-2 text-slate-200 lg:hidden"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="border-t border-white/10 bg-[#061021] px-4 py-4 lg:hidden">
            <div className="flex flex-col space-y-2.5">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateTo(item.id)}
                  className="rounded-lg px-3 py-2 text-left text-sm font-medium text-slate-200 hover:bg-white/5"
                >
                  {item.label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => navigateTo("admin")}
                className="rounded-lg px-3 py-2 text-left text-sm font-medium text-cyan-300 hover:bg-white/5"
              >
                Admin Control Center
              </button>
              <button
                type="button"
                onClick={() => navigateTo("quote")}
                className="mt-2 inline-flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-4 py-2.5 text-sm font-semibold text-slate-950"
              >
                Get a Quote
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </header>

      <main className="relative z-10">
        {/* HERO SECTION */}
        <section id="home" className="mx-auto max-w-7xl px-4 pt-12 pb-16 sm:px-6 lg:px-8 lg:pt-16">
          <div className="grid items-center gap-10 lg:grid-cols-12">
            <div className="space-y-6 lg:col-span-6">
              <div className="inline-flex flex-wrap items-center gap-2 rounded-full border border-cyan-400/25 bg-cyan-500/10 px-3.5 py-1.5 text-xs font-medium text-cyan-200">
                <Droplets className="h-3.5 w-3.5 text-cyan-400" />
                <span>AQUASENSE • &ldquo;Intelligence for Every Drop.&rdquo;</span>
                <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-emerald-300">
                  Demo Mode
                </span>
              </div>

              <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-[3.35rem] lg:leading-[1.1]">
                Smarter Water Management Starts With{" "}
                <span className="bg-gradient-to-r from-cyan-300 via-sky-300 to-emerald-300 bg-clip-text text-transparent">
                  Intelligence.
                </span>
              </h1>

              <p className="max-w-xl text-base leading-relaxed text-slate-300">
                Discover a sensor-based wastewater monitoring and diversion prototype designed to
                demonstrate intelligent water-quality monitoring, automated routing and multi-stage
                filtration.
              </p>

              <div className="flex flex-wrap items-center gap-3.5 pt-1">
                <button
                  type="button"
                  onClick={() => navigateTo("technology")}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-5 py-3 text-sm font-semibold text-slate-950 shadow-[0_0_28px_rgba(34,211,238,0.28)] hover:brightness-110 transition"
                >
                  Explore Technology
                  <ArrowRight className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo("quote")}
                  className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/[0.04] px-5 py-3 text-sm font-semibold text-white hover:border-cyan-400/40 hover:bg-white/[0.08] transition"
                >
                  Request a Demo
                </button>
              </div>

              {/* Interactive Parameter Controls */}
              <div className="rounded-2xl border border-white/10 bg-[#071224]/85 p-4 backdrop-blur-md">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-200">
                    <Sliders className="h-3.5 w-3.5 text-cyan-400" />
                    Test Prototype Telemetry Inputs
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setPh(7.2);
                        setTurbidity(14);
                        setFlowRate(4.5);
                      }}
                      className="rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-200 hover:bg-emerald-500/20"
                    >
                      Normal Sample
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPh(7.0);
                        setTurbidity(68);
                        setFlowRate(5.2);
                      }}
                      className="rounded-lg border border-amber-400/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-medium text-amber-200 hover:bg-amber-500/20"
                    >
                      Turbidity Spike
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPh(4.8);
                        setTurbidity(18);
                        setFlowRate(4.0);
                      }}
                      className="rounded-lg border border-rose-400/30 bg-rose-500/10 px-2.5 py-1 text-[11px] font-medium text-rose-200 hover:bg-rose-500/20"
                    >
                      Acidic Surge
                    </button>
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <div>
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>pH Level</span>
                      <span className="font-semibold text-cyan-300 tabular-nums">{ph.toFixed(1)}</span>
                    </div>
                    <input
                      type="range"
                      min="3.0"
                      max="11.0"
                      step="0.1"
                      value={ph}
                      onChange={(e) => setPh(parseFloat(e.target.value))}
                      className="mt-1.5 w-full accent-cyan-400"
                      aria-label="Adjust sample pH"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>Turbidity</span>
                      <span className="font-semibold text-cyan-300 tabular-nums">{turbidity} NTU</span>
                    </div>
                    <input
                      type="range"
                      min="2"
                      max="120"
                      step="1"
                      value={turbidity}
                      onChange={(e) => setTurbidity(parseInt(e.target.value, 10))}
                      className="mt-1.5 w-full accent-cyan-400"
                      aria-label="Adjust sample turbidity in NTU"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>Flow Rate</span>
                      <span className="font-semibold text-emerald-300 tabular-nums">{flowRate.toFixed(1)} L/m</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="12.0"
                      step="0.5"
                      value={flowRate}
                      onChange={(e) => setFlowRate(parseFloat(e.target.value))}
                      className="mt-1.5 w-full accent-emerald-400"
                      aria-label="Adjust flow rate in liters per minute"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6">
              <HeroSystemDiagram
                ph={ph}
                turbidity={turbidity}
                flowRate={flowRate}
                isDiverted={logicEvaluation.isDiverted}
              />
            </div>
          </div>

          {/* Brand Intro & Core Highlights Strip */}
          <div className="mt-14 grid gap-4 border-t border-white/10 pt-10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: Activity,
                title: "Real-Time Sensing",
                desc: "Continuous prototype monitoring of pH, optical turbidity, and volumetric flow."
              },
              {
                icon: Cpu,
                title: "Automated Diversion",
                desc: "Arduino UNO threshold rules drive servo actuation and clear LED status signals."
              },
              {
                icon: Layers,
                title: "6-Stage Demo Filtration",
                desc: "Visual progression from coarse screening and settling to polishing and quality check."
              },
              {
                icon: ShieldCheck,
                title: "Transparent Scope",
                desc: "Built for education, lab experimentation, and conceptual architecture validation."
              }
            ].map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.title}
                  className="rounded-2xl border border-white/10 bg-white/[0.025] p-5 hover:border-cyan-400/30 transition"
                >
                  <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-300">
                    <Icon className="h-4 w-4" />
                  </div>
                  <h3 className="text-sm font-semibold text-white">{card.title}</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-400">{card.desc}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* TECHNOLOGY EXPERIENCE (UNIT A, UNIT B, UNIT C) */}
        <section id="technology" className="border-t border-white/10 bg-[#061021]/70 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                04 • Technology Experience
              </p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Three Modular Units Engineered for Clear Demonstration
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-slate-300">
                AQUASENSE separates sensing, automated routing decisions, and demonstration treatment
                into distinct modules so students, researchers, and evaluators can inspect each layer.
              </p>
            </div>

            {/* Unit Selector Tabs */}
            <div className="mt-8 flex flex-wrap gap-2.5">
              {[
                { id: "unit-a", label: "Unit A — Intelligent Monitoring" },
                { id: "unit-b", label: "Unit B — Automation and Control" },
                { id: "unit-c", label: "Unit C — Demonstration Treatment" }
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveUnitTab(tab.id)}
                  className={`rounded-xl px-4 py-2.5 text-xs font-semibold transition ${
                    activeUnitTab === tab.id
                      ? "bg-cyan-400 text-slate-950 shadow-[0_0_20px_rgba(34,211,238,0.25)]"
                      : "border border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* UNIT A */}
            {activeUnitTab === "unit-a" && (
              <div className="mt-6 grid gap-5 md:grid-cols-3">
                {[
                  {
                    name: "pH Sensor",
                    metric: "Acidity / Alkalinity Indicator",
                    body: "Tracks hydrogen-ion activity across acidic, neutral, and alkaline test streams. Shifts outside a nominal band (such as 6.5–8.5 in demo rules) can trigger diversion logic."
                  },
                  {
                    name: "Turbidity Sensor",
                    metric: "Optical Suspended Solids Proxy",
                    body: "Measures light scattering caused by suspended particles (NTU) in the sample stream, helping demonstrate how cloudier water affects downstream filtration load."
                  },
                  {
                    name: "Flow Sensor",
                    metric: "Volumetric Flow Rate Telemetry",
                    body: "Monitors liquid movement through the prototype line so the controller can verify active flow before actuating valves or logging run intervals."
                  }
                ].map((s) => (
                  <div
                    key={s.name}
                    className="rounded-2xl border border-white/10 bg-[#08152b] p-6"
                  >
                    <span className="rounded-md bg-cyan-500/15 px-2.5 py-1 text-[11px] font-semibold text-cyan-300">
                      {s.metric}
                    </span>
                    <h3 className="mt-4 text-lg font-bold text-white">{s.name}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">{s.body}</p>
                  </div>
                ))}
              </div>
            )}

            {/* UNIT B */}
            {activeUnitTab === "unit-b" && (
              <div className="mt-6 grid gap-6 lg:grid-cols-12">
                <div className="space-y-4 rounded-2xl border border-white/10 bg-[#08152b] p-6 lg:col-span-6">
                  <h3 className="text-lg font-bold text-white">
                    Components: Arduino UNO, Servo Motor, Diverter Valve &amp; LEDs
                  </h3>
                  <p className="text-sm leading-relaxed text-slate-300">
                    Arduino UNO reads incoming sensor signals, evaluates programmed threshold rules,
                    positions the servo motor connected to the diverter valve, and drives clear LED
                    status indicators so observers can immediately see routing decisions.
                  </p>
                  <ul className="space-y-2.5 text-xs text-slate-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-cyan-400" />
                      <span>
                        <strong className="text-white">Arduino UNO:</strong> Central microcontroller
                        executing threshold comparison and actuator commands.
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-cyan-400" />
                      <span>
                        <strong className="text-white">Servo Motor &amp; Diverter Valve:</strong>{" "}
                        Mechanically switches flow direction between demonstration treatment and hold/diversion.
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                      <span>
                        <strong className="text-white">LED Status Indicators:</strong> Visual indicators
                        for normal operation, warning/diversion state, and active actuation.
                      </span>
                    </li>
                  </ul>
                </div>

                <div className="rounded-2xl border border-cyan-400/25 bg-[#050e1f] p-6 lg:col-span-6">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <span className="text-xs font-semibold uppercase tracking-wider text-cyan-300">
                      Live Threshold Logic Evaluator
                    </span>
                    <span className="text-xs text-slate-400">Synced with Hero Sliders</span>
                  </div>
                  <div className="mt-4 space-y-3 text-xs">
                    <div className="flex justify-between rounded-lg bg-white/[0.03] px-3.5 py-2.5">
                      <span className="text-slate-400">Servo Actuator Position</span>
                      <span className="font-semibold text-white">{logicEvaluation.servoAngle}</span>
                    </div>
                    <div className="flex justify-between rounded-lg bg-white/[0.03] px-3.5 py-2.5">
                      <span className="text-slate-400">LED Status Output</span>
                      <span className="font-semibold text-cyan-300">{logicEvaluation.ledState}</span>
                    </div>
                    <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3.5">
                      <p className="font-semibold text-slate-200">Decision Summary:</p>
                      {logicEvaluation.reasons.length === 0 ? (
                        <p className="mt-1 text-emerald-300">
                          All demo thresholds satisfied. Stream routed to demonstration treatment.
                        </p>
                      ) : (
                        <ul className="mt-1.5 list-disc pl-4 text-amber-300 space-y-1">
                          {logicEvaluation.reasons.map((r) => (
                            <li key={r}>{r}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* UNIT C — 6 STAGES */}
            {activeUnitTab === "unit-c" && (
              <div className="mt-6 grid gap-6 lg:grid-cols-12">
                <div className="grid gap-2.5 sm:grid-cols-2 lg:col-span-7">
                  {TREATMENT_STAGES.map((stage) => {
                    const active = selectedStage.step === stage.step;
                    return (
                      <button
                        key={stage.step}
                        type="button"
                        onClick={() => setSelectedStage(stage)}
                        className={`flex items-center justify-between rounded-xl border p-4 text-left transition ${
                          active
                            ? "border-cyan-400 bg-cyan-500/15 text-white"
                            : "border-white/10 bg-[#08152b] text-slate-300 hover:border-white/25"
                        }`}
                      >
                        <div>
                          <span className="text-[11px] font-bold text-cyan-400">
                            STAGE 0{stage.step}
                          </span>
                          <p className="mt-0.5 text-sm font-semibold text-white">{stage.title}</p>
                        </div>
                        <ArrowRight className={`h-4 w-4 ${active ? "text-cyan-300" : "text-slate-500"}`} />
                      </button>
                    );
                  })}
                </div>

                <div className="flex flex-col justify-between rounded-2xl border border-emerald-400/25 bg-[#08152b] p-6 lg:col-span-5">
                  <div>
                    <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-300">
                      Stage 0{selectedStage.step} Selected
                    </span>
                    <h3 className="mt-4 text-2xl font-bold text-white">{selectedStage.title}</h3>
                    <p className="mt-1 text-xs font-medium text-cyan-300">{selectedStage.subtitle}</p>
                    <p className="mt-4 text-sm leading-relaxed text-slate-200">
                      {selectedStage.summary}
                    </p>
                    <p className="mt-3 text-xs leading-relaxed text-slate-400">
                      {selectedStage.detail}
                    </p>
                  </div>
                  <div className="mt-6 border-t border-white/10 pt-4 text-[11px] text-slate-400">
                    Click any stage card on the left to inspect its demonstration role.
                  </div>
                </div>
              </div>
            )}

            {/* IMPORTANT SCIENTIFIC ACCURACY DISCLAIMER */}
            <div className="mt-10 rounded-2xl border border-amber-400/35 bg-amber-950/25 p-5 sm:p-6">
              <div className="flex items-start gap-3.5">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
                <div className="space-y-1.5">
                  <h3 className="text-sm font-bold tracking-wide text-amber-200 uppercase">
                    Important Scientific Accuracy &amp; Regulatory Notice
                  </h3>
                  <p className="text-xs leading-relaxed text-amber-100/90 sm:text-sm">
                    pH and turbidity measurements do not identify every industrial pollutant. Basic
                    filtration cannot guarantee removal of dissolved chemicals, heavy metals or all
                    hazardous substances. The prototype is not certified for drinking water or
                    industrial discharge. Actual treatment requires pollutant-specific analysis,
                    suitable treatment processes and applicable regulatory approval.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* INTERACTIVE SYSTEM FLOW */}
        <section className="border-t border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold tracking-[0.18em] text-emerald-400 uppercase">
                05 • Interactive System Flow
              </p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                End-to-End Prototype Signal &amp; Water Flow
              </h2>
              <p className="mt-3 text-sm text-slate-300">
                Select any stage in the sequence below to inspect how water moves and how control
                decisions are made.
              </p>
            </div>

            <div className="mt-8 grid gap-6 lg:grid-cols-12">
              <div className="space-y-2.5 lg:col-span-7">
                {FLOW_NODES.map((node, idx) => {
                  const isSelected = selectedFlowNode.id === node.id;
                  return (
                    <div key={node.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedFlowNode(node)}
                        className={`flex w-full items-center justify-between rounded-xl border px-4 py-3.5 text-left transition ${
                          isSelected
                            ? "border-cyan-400 bg-cyan-500/15 text-white"
                            : "border-white/10 bg-[#08152b] text-slate-200 hover:border-white/25"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10 text-[11px] font-bold text-cyan-300">
                            {idx + 1}
                          </span>
                          <div>
                            <p className="text-sm font-semibold text-white">{node.label}</p>
                            <p className="text-xs text-slate-400">{node.short}</p>
                          </div>
                        </div>
                        <ArrowRight className="h-4 w-4 text-cyan-300" />
                      </button>
                      {idx < FLOW_NODES.length - 1 && (
                        <div className="flex justify-center py-1 text-cyan-400/70" aria-hidden="true">
                          <span className="text-xs font-bold animate-bounce">&darr;</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="lg:col-span-5">
                <div className="sticky top-24 rounded-2xl border border-white/10 bg-[#08152b] p-6">
                  <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
                    Stage Inspector
                  </span>
                  <h3 className="mt-2 text-xl font-bold text-white">{selectedFlowNode.label}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-200">
                    {selectedFlowNode.description}
                  </p>
                  <div className="mt-4 rounded-xl border border-white/10 bg-[#050d1c] p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-emerald-300">
                      Technical Context
                    </p>
                    <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                      {selectedFlowNode.technical}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* PRODUCT SHOWCASE */}
        <section id="solutions" className="border-t border-white/10 bg-[#061021]/70 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="max-w-3xl">
                <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                  06 • Product Showcase
                </p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                  Demonstration Configurations &amp; Illustrative Pricing
                </h2>
                <p className="mt-3 text-sm text-slate-300">
                  Prices shown below are <strong>proposed illustrative prices</strong> for planning
                  and academic/demonstration evaluation—not confirmed commercial prices or
                  certified treatment guarantees.
                </p>
              </div>
            </div>

            <div className="mt-10 grid gap-6 lg:grid-cols-3">
              {products.map((prod) => (
                <div
                  key={prod.id}
                  className="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#08152b] p-6 hover:border-cyan-400/35 transition"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="rounded-full bg-cyan-500/15 px-3 py-1 text-[11px] font-semibold text-cyan-300">
                        {prod.badge}
                      </span>
                      <span className="text-[11px] text-amber-300/90 font-medium">
                        {prod.type}
                      </span>
                    </div>
                    <h3 className="mt-4 text-xl font-bold text-white">{prod.name}</h3>
                    <p className="mt-2 text-3xl font-extrabold text-white">{prod.priceLabel}</p>
                    <p className="mt-3 text-xs leading-relaxed text-slate-300">
                      {prod.description}
                    </p>

                    <ul className="mt-5 space-y-2 border-t border-white/10 pt-4 text-xs text-slate-300">
                      {prod.specs.map((spec) => (
                        <li key={spec} className="flex items-start gap-2">
                          <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                          <span>{spec}</span>
                        </li>
                      ))}
                    </ul>

                    <p className="mt-4 rounded-lg bg-amber-950/30 border border-amber-400/20 p-2.5 text-[11px] text-amber-200/90">
                      {prod.limitations}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setInquiryForm((prev) => ({ ...prev, interestedProduct: prod.name }));
                      navigateTo("quote");
                    }}
                    className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-cyan-400/40 bg-cyan-500/10 px-4 py-2.5 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/20 transition"
                  >
                    Inquire About {prod.name}
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Architecture, Limitations & Roadmap Summary */}
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              <div className="rounded-2xl border border-white/10 bg-[#050d1c] p-5">
                <h4 className="text-sm font-bold text-white">Working Principle &amp; Architecture</h4>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  Combines inline sensor probes, Arduino threshold rules, a servo diverter valve,
                  and a 6-step demonstration filtration path to visualize automated routing
                  concepts.
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-[#050d1c] p-5">
                <h4 className="text-sm font-bold text-white">Technical Limitations</h4>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  Prototype sensors require periodic calibration; basic media stages do not replace
                  specialized chemical/biological treatment or laboratory compliance testing.
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-[#050d1c] p-5">
                <h4 className="text-sm font-bold text-white">Future Development Roadmap</h4>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  Planned exploration includes structured telemetry logging, calibrated benchtop test
                  modules, and optional IoT monitoring concepts following lab validation.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* SOLUTIONS AND APPLICATIONS */}
        <section id="applications" className="border-t border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold tracking-[0.18em] text-emerald-400 uppercase">
                07 • Solutions and Applications
              </p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Designed for Demonstration, Learning &amp; Conceptual Exploration
              </h2>
              <p className="mt-3 text-sm text-slate-300">
                Educational and laboratory demonstration use is distinct from validated industrial
                treatment. Any industrial application requires engineering assessment, pollutant-specific
                testing, and regulatory approval.
              </p>
            </div>

            <div className="mt-10 grid gap-6 md:grid-cols-2">
              {[
                {
                  icon: GraduationCap,
                  title: "Educational Institutions",
                  badge: "Demonstration & Learning",
                  desc: "Supports Arduino learning, sensor experiments, water-quality demonstrations, and environmental awareness in classrooms and student clubs."
                },
                {
                  icon: FlaskConical,
                  title: "Colleges and Laboratories",
                  badge: "Lab Experimentation",
                  desc: "Enables controlled sample testing demonstrations, sensor calibration experiments, and comparative filtration studies under faculty supervision."
                },
                {
                  icon: Building2,
                  title: "Small Industrial Units",
                  badge: "Conceptual Only — Validation Required",
                  desc: "Presents a conceptual monitoring and diversion approach that may be adapted only after industrial testing, engineering validation, and compliance review."
                },
                {
                  icon: Microscope,
                  title: "Research and Innovation",
                  badge: "R&D & Prototyping",
                  desc: "Provides a hands-on platform for learning, experimentation, and future IoT-based monitoring development."
                }
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.title}
                    className="rounded-2xl border border-white/10 bg-[#08152b] p-6"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-300">
                        <Icon className="h-5 w-5" />
                      </div>
                      <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-medium text-cyan-200">
                        {item.badge}
                      </span>
                    </div>
                    <h3 className="mt-4 text-lg font-bold text-white">{item.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">{item.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ABOUT THE TEAM */}
        <section id="about" className="border-t border-white/10 bg-[#061021]/70 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-10 lg:grid-cols-12">
              <div className="lg:col-span-6">
                <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                  11 • About THE THINKERS
                </p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                  Driven by Innovation. Designed for a Better Water Future.
                </h2>
                <p className="mt-4 text-sm leading-relaxed text-slate-300">
                  AQUASENSE is an environmental technology prototype developed by{" "}
                  <strong className="text-white">THE THINKERS</strong> to explore how sensors,
                  automation and demonstration filtration can contribute to smarter wastewater
                  management.
                </p>
                <blockquote className="mt-6 rounded-xl border-l-2 border-cyan-400 bg-white/[0.03] p-4 text-sm italic text-cyan-100">
                  &ldquo;{visionStatement}&rdquo;
                </blockquote>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:col-span-6">
                <div className="rounded-2xl border border-white/10 bg-[#08152b] p-5">
                  <h3 className="text-sm font-bold text-white">Mission</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-300">
                    Make water-quality sensing, automated threshold logic, and multi-stage
                    filtration principles clear and interactive for learners and evaluators.
                  </p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-[#08152b] p-5">
                  <h3 className="text-sm font-bold text-white">Innovation Approach</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-300">
                    Combine accessible microcontroller hardware, visible process stages, and honest
                    engineering boundaries without overstating prototype capabilities.
                  </p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-[#08152b] p-5">
                  <h3 className="text-sm font-bold text-white">Team Identity</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-300">
                    Created by <strong className="text-cyan-300">THE THINKERS</strong> as a focused
                    prototyping and demonstration initiative around AQUASENSE.
                  </p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-[#08152b] p-5">
                  <h3 className="text-sm font-bold text-white">Project Journey</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-300">
                    Evolved from schematic and sensor-threshold concepts into an interactive
                    three-unit demonstration architecture and digital showcase.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CUSTOMER ORDER & LEAD MANAGEMENT (QUOTATION FORM) */}
        <section id="quote" className="border-t border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-10 lg:grid-cols-12">
              <div className="lg:col-span-5">
                <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                  08 • Inquiry &amp; Quotation
                </p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-white">
                  Request a Demo or Illustrative Quote
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-slate-300">
                  Submit your requirements for educational kits, lab demonstration rigs, or
                  institutional discussions.
                </p>

                <div className="mt-5 rounded-xl border border-amber-400/30 bg-amber-950/25 p-4 text-xs text-amber-200">
                  <strong>Demo Mode Notice:</strong> Because no live backend is connected here,
                  submitted inquiries are stored locally in browser state for demonstration and are
                  not transmitted to an external server.
                </div>

                {lastSubmittedInquiry && (
                  <div className="mt-5 rounded-2xl border border-emerald-400/35 bg-emerald-950/25 p-5">
                    <div className="flex items-center gap-2 text-sm font-bold text-emerald-300">
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Demo Inquiry Recorded</span>
                    </div>
                    <p className="mt-1 text-xs text-emerald-100">
                      Reference ID: <strong className="font-mono">{lastSubmittedInquiry.id}</strong>
                    </p>
                    <p className="mt-1 text-xs text-slate-300">
                      Product: {lastSubmittedInquiry.interestedProduct} (Qty:{" "}
                      {lastSubmittedInquiry.quantity})
                    </p>
                  </div>
                )}
              </div>

              <form
                onSubmit={handleInquirySubmit}
                noValidate
                className="grid gap-4 rounded-2xl border border-white/10 bg-[#08152b] p-6 sm:grid-cols-2 lg:col-span-7"
              >
                <div>
                  <label className="block text-xs font-medium text-slate-300">Full Name *</label>
                  <input
                    type="text"
                    value={inquiryForm.fullName}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, fullName: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="Your full name"
                  />
                  {inquiryErrors.fullName && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.fullName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Email *</label>
                  <input
                    type="email"
                    value={inquiryForm.email}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, email: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="name@institution.edu"
                  />
                  {inquiryErrors.email && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.email}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Phone Number *</label>
                  <input
                    type="tel"
                    value={inquiryForm.phone}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, phone: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="+91 XXXXX XXXXX"
                  />
                  {inquiryErrors.phone && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.phone}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Organization *</label>
                  <input
                    type="text"
                    value={inquiryForm.organization}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, organization: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="School, College, Lab, or Unit"
                  />
                  {inquiryErrors.organization && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.organization}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Location *</label>
                  <input
                    type="text"
                    value={inquiryForm.location}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, location: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="City, State"
                  />
                  {inquiryErrors.location && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.location}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">
                    Interested Product
                  </label>
                  <select
                    value={inquiryForm.interestedProduct}
                    onChange={(e) =>
                      setInquiryForm({ ...inquiryForm, interestedProduct: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.name}>
                        {p.name} ({p.priceLabel})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Quantity *</label>
                  <input
                    type="number"
                    min="1"
                    value={inquiryForm.quantity}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, quantity: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                  />
                  {inquiryErrors.quantity && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.quantity}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Budget Range</label>
                  <select
                    value={inquiryForm.budgetRange}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, budgetRange: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="₹2,000 – ₹5,000">₹2,000 – ₹5,000</option>
                    <option value="₹5,000 – ₹15,000">₹5,000 – ₹15,000</option>
                    <option value="₹15,000+ (Custom)">₹15,000+ (Custom)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-300">Message *</label>
                  <textarea
                    rows="3"
                    value={inquiryForm.message}
                    onChange={(e) => setInquiryForm({ ...inquiryForm, message: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                    placeholder="Share your demonstration goals, lab setup, or preferred timeline..."
                  />
                  {inquiryErrors.message && (
                    <p className="mt-1 text-xs text-rose-400">{inquiryErrors.message}</p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    disabled={isSubmittingInquiry}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-5 py-3 text-sm font-semibold text-slate-950 hover:brightness-110 disabled:opacity-60 transition"
                  >
                    {isSubmittingInquiry ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span>Recording Demo Inquiry...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        <span>Submit Inquiry (Demo Mode)</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </section>

        {/* CUSTOMER FEEDBACK & MODERATED REVIEWS */}
        <section id="feedback" className="border-t border-white/10 bg-[#061021]/70 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                09 • Feedback &amp; Moderation
              </p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Share Feedback &amp; Suggestions
              </h2>
              <p className="mt-3 text-sm text-slate-300">
                New entries are marked as <strong>Demo Entry</strong> in this local preview and
                require moderation approval before appearing in the public feed.
              </p>
            </div>

            <div className="mt-10 grid gap-8 lg:grid-cols-12">
              <form
                onSubmit={handleReviewSubmit}
                className="space-y-4 rounded-2xl border border-white/10 bg-[#08152b] p-6 lg:col-span-5"
              >
                <div>
                  <label className="block text-xs font-medium text-slate-300">Rating *</label>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                        aria-label={`Rate ${star} out of 5 stars`}
                        className="rounded-lg p-1 text-amber-400 hover:bg-white/5"
                      >
                        <Star
                          className={`h-5 w-5 ${
                            star <= reviewForm.rating ? "fill-amber-400 text-amber-400" : "text-slate-600"
                          }`}
                        />
                      </button>
                    ))}
                    <span className="ml-2 text-xs font-semibold text-amber-300">
                      {reviewForm.rating} / 5
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Name *</label>
                  <input
                    type="text"
                    value={reviewForm.name}
                    onChange={(e) => setReviewForm({ ...reviewForm, name: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2 text-sm text-white"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">
                    Organization (Optional)
                  </label>
                  <input
                    type="text"
                    value={reviewForm.organization}
                    onChange={(e) => setReviewForm({ ...reviewForm, organization: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2 text-sm text-white"
                    placeholder="Institution or team"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">Feedback *</label>
                  <textarea
                    rows="3"
                    value={reviewForm.feedback}
                    onChange={(e) => setReviewForm({ ...reviewForm, feedback: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2 text-sm text-white"
                    placeholder="What stood out about the prototype explanation and interface?"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300">
                    Suggestions (Optional)
                  </label>
                  <input
                    type="text"
                    value={reviewForm.suggestions}
                    onChange={(e) => setReviewForm({ ...reviewForm, suggestions: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2 text-sm text-white"
                    placeholder="Ideas for future demos or documentation"
                  />
                </div>

                {reviewSubmittedMessage && (
                  <p className="rounded-lg border border-cyan-400/30 bg-cyan-500/10 p-3 text-xs text-cyan-200">
                    {reviewSubmittedMessage}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full rounded-xl bg-cyan-400 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:brightness-110 transition"
                >
                  Submit for Moderation (Demo)
                </button>
              </form>

              <div className="space-y-4 lg:col-span-7">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                    Approved Entries ({approvedReviews.length})
                  </h3>
                  <span className="text-xs text-slate-400">
                    Pending entries can be approved in Admin below
                  </span>
                </div>

                {approvedReviews.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center text-sm text-slate-400">
                    No approved feedback entries yet.
                  </div>
                ) : (
                  approvedReviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="rounded-2xl border border-white/10 bg-[#08152b] p-5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm font-bold text-white">{rev.name}</p>
                          <p className="text-xs text-slate-400">{rev.organization}</p>
                        </div>
                        <div className="flex items-center gap-1 text-amber-400">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-amber-400" />
                          ))}
                          <span className="ml-2 text-[11px] text-slate-400">{rev.date}</span>
                        </div>
                      </div>
                      <p className="mt-3 text-sm text-slate-200">{rev.feedback}</p>
                      {rev.suggestions && (
                        <p className="mt-2 text-xs text-cyan-300/90">
                          Suggestion: {rev.suggestions}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </section>

        {/* CONTACT & FAQ */}
        <section id="contact" className="border-t border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-10 lg:grid-cols-12">
              <div className="space-y-4 rounded-2xl border border-white/10 bg-[#08152b] p-6 lg:col-span-5">
                <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                  12 • Contact &amp; Business Development
                </p>
                <h2 className="text-2xl font-bold text-white">Connect With {contactInfo.brandName}</h2>
                <p className="text-xs leading-relaxed text-slate-300">
                  Reach out for business inquiries, institutional collaborations, or prototype demo
                  sessions with {contactInfo.teamName}.
                </p>

                <div className="space-y-3 pt-2 text-xs text-slate-200">
                  <div className="flex items-center gap-2.5">
                    <Mail className="h-4 w-4 text-cyan-400" />
                    <span>{contactInfo.email}</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <Phone className="h-4 w-4 text-cyan-400" />
                    <span>{contactInfo.phone}</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <MapPin className="h-4 w-4 text-emerald-400" />
                    <span>{contactInfo.location}</span>
                  </div>
                </div>

                <div className="grid gap-2.5 border-t border-white/10 pt-4 text-xs">
                  <div className="rounded-xl bg-white/[0.03] p-3">
                    <p className="font-semibold text-white">Business &amp; Institutional Inquiries</p>
                    <p className="mt-0.5 text-slate-400">
                      Academic labs, workshops, and collaborative prototype evaluation.
                    </p>
                  </div>
                  <div className="rounded-xl bg-white/[0.03] p-3">
                    <p className="font-semibold text-white">Demo Requests</p>
                    <p className="mt-0.5 text-slate-400">
                      Walkthroughs of sensor telemetry, servo diversion, and 6-stage flow.
                    </p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7">
                <h3 className="text-xl font-bold text-white">Frequently Asked Questions</h3>
                <div className="mt-4 space-y-3">
                  {FAQ_ITEMS.map((faq, idx) => {
                    const isOpen = openFaqIndex === idx;
                    return (
                      <div
                        key={faq.q}
                        className="rounded-xl border border-white/10 bg-[#08152b] overflow-hidden"
                      >
                        <button
                          type="button"
                          onClick={() => setOpenFaqIndex(isOpen ? -1 : idx)}
                          className="flex w-full items-center justify-between px-4 py-3.5 text-left text-sm font-semibold text-white"
                        >
                          <span>{faq.q}</span>
                          {isOpen ? (
                            <ChevronUp className="h-4 w-4 shrink-0 text-cyan-400" />
                          ) : (
                            <ChevronDown className="h-4 w-4 shrink-0 text-slate-400" />
                          )}
                        </button>
                        {isOpen && (
                          <div className="border-t border-white/10 px-4 py-3 text-xs leading-relaxed text-slate-300">
                            {faq.a}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ADMIN CONTROL CENTER */}
        <section id="admin" className="border-t border-white/10 bg-[#061021]/90 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-xs font-semibold tracking-[0.18em] text-cyan-400 uppercase">
                  10 &amp; 13 • Admin Control Center &amp; Schema Blueprint
                </p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-white">
                  Operations, Moderation &amp; Settings
                </h2>
              </div>
              {isAdminAuthenticated && (
                <button
                  type="button"
                  onClick={() => setIsAdminAuthenticated(false)}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-white/15 px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-white/5"
                >
                  <Lock className="h-3.5 w-3.5" />
                  Lock Admin Session
                </button>
              )}
            </div>

            {!isAdminAuthenticated ? (
              <form
                onSubmit={handleAdminUnlock}
                className="mt-8 max-w-md rounded-2xl border border-white/10 bg-[#08152b] p-6"
              >
                <div className="flex items-center gap-2 text-sm font-bold text-white">
                  <Unlock className="h-4 w-4 text-cyan-400" />
                  <span>Local Demo Admin Access</span>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  No production secrets or admin passwords are embedded in client code. Enter any
                  4+ character label below to preview the local admin workspace (connect Supabase
                  Auth for production).
                </p>
                <input
                  type="password"
                  value={adminPasscodeInput}
                  onChange={(e) => setAdminPasscodeInput(e.target.value)}
                  placeholder="Enter demo label (e.g. demo-admin)"
                  className="mt-4 w-full rounded-xl border border-white/10 bg-[#050d1c] px-3.5 py-2.5 text-sm text-white"
                />
                {adminAuthError && (
                  <p className="mt-1.5 text-xs text-rose-400">{adminAuthError}</p>
                )}
                <button
                  type="submit"
                  className="mt-4 w-full rounded-xl bg-cyan-400 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:brightness-110 transition"
                >
                  Open Admin Control Center (Demo)
                </button>
              </form>
            ) : (
              <div className="mt-8 space-y-6">
                {/* Metrics Row */}
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                  <div className="rounded-xl border border-white/10 bg-[#08152b] p-4">
                    <p className="text-xs text-slate-400">Total Inquiries</p>
                    <p className="mt-1 text-2xl font-bold text-white">{inquiries.length}</p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-[#08152b] p-4">
                    <p className="text-xs text-slate-400">Pending Inquiries</p>
                    <p className="mt-1 text-2xl font-bold text-amber-300">
                      {inquiries.filter((i) => i.status === "Pending").length}
                    </p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-[#08152b] p-4">
                    <p className="text-xs text-slate-400">Processed Inquiries</p>
                    <p className="mt-1 text-2xl font-bold text-emerald-300">
                      {inquiries.filter((i) => i.status === "Processed").length}
                    </p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-[#08152b] p-4">
                    <p className="text-xs text-slate-400">Total Feedback</p>
                    <p className="mt-1 text-2xl font-bold text-cyan-300">{reviews.length}</p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-[#08152b] p-4">
                    <p className="text-xs text-slate-400">Average Rating</p>
                    <p className="mt-1 text-2xl font-bold text-white">{avgRating} / 5</p>
                  </div>
                </div>

                {/* Sub-tabs */}
                <div className="flex flex-wrap gap-2">
                  {[
                    { id: "inquiries", label: "Inquiries" },
                    { id: "moderation", label: "Feedback Moderation" },
                    { id: "pricing", label: "Pricing & Content" },
                    { id: "settings", label: "Contact & Schema SQL" }
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setAdminTab(t.id)}
                      className={`rounded-lg px-3.5 py-2 text-xs font-semibold ${
                        adminTab === t.id
                          ? "bg-cyan-400 text-slate-950"
                          : "border border-white/10 bg-[#08152b] text-slate-300"
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                {adminTab === "inquiries" && (
                  <div className="rounded-2xl border border-white/10 bg-[#08152b] p-5">
                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                      <div className="relative w-full sm:w-72">
                        <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                        <input
                          type="text"
                          value={inquirySearch}
                          onChange={(e) => setInquirySearch(e.target.value)}
                          placeholder="Search ID, name, organization..."
                          className="w-full rounded-xl border border-white/10 bg-[#050d1c] pl-9 pr-3 py-2 text-xs text-white"
                        />
                      </div>
                      <select
                        value={inquiryStatusFilter}
                        onChange={(e) => setInquiryStatusFilter(e.target.value)}
                        className="rounded-xl border border-white/10 bg-[#050d1c] px-3 py-2 text-xs text-white"
                      >
                        <option value="All">All Statuses</option>
                        <option value="Pending">Pending</option>
                        <option value="Processed">Processed</option>
                      </select>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-white/10 text-slate-400">
                            <th className="py-2.5 pr-4">Ref ID</th>
                            <th className="py-2.5 pr-4">Contact</th>
                            <th className="py-2.5 pr-4">Product &amp; Qty</th>
                            <th className="py-2.5 pr-4">Status</th>
                            <th className="py-2.5 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/10">
                          {filteredInquiries.map((inq) => (
                            <tr key={inq.id}>
                              <td className="py-3 pr-4 font-mono text-cyan-300">{inq.id}</td>
                              <td className="py-3 pr-4">
                                <p className="font-semibold text-white">{inq.fullName}</p>
                                <p className="text-slate-400">{inq.organization}</p>
                              </td>
                              <td className="py-3 pr-4">
                                <p className="text-white">{inq.interestedProduct}</p>
                                <p className="text-slate-400">
                                  Qty: {inq.quantity} • {inq.budgetRange}
                                </p>
                              </td>
                              <td className="py-3 pr-4">
                                <span
                                  className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${
                                    inq.status === "Processed"
                                      ? "bg-emerald-500/15 text-emerald-300"
                                      : "bg-amber-500/15 text-amber-300"
                                  }`}
                                >
                                  {inq.status}
                                </span>
                              </td>
                              <td className="py-3 text-right">
                                <div className="inline-flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateInquiryStatus(
                                        inq.id,
                                        inq.status === "Processed" ? "Pending" : "Processed"
                                      )
                                    }
                                    className="rounded-lg border border-cyan-400/30 bg-cyan-500/10 px-2.5 py-1 text-[11px] font-medium text-cyan-200"
                                  >
                                    Toggle Status
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => deleteInquiry(inq.id)}
                                    className="rounded-lg border border-rose-400/30 bg-rose-500/10 p-1.5 text-rose-300"
                                    aria-label={`Delete ${inq.id}`}
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {adminTab === "moderation" && (
                  <div className="space-y-3 rounded-2xl border border-white/10 bg-[#08152b] p-5">
                    {reviews.map((r) => (
                      <div
                        key={r.id}
                        className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-white/10 bg-[#050d1c] p-4"
                      >
                        <div className="max-w-xl">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white">{r.name}</span>
                            <span className="rounded bg-white/10 px-2 py-0.5 text-[10px] text-cyan-300">
                              {r.rating}★ • {r.status}
                            </span>
                          </div>
                          <p className="mt-1 text-xs text-slate-300">{r.feedback}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {r.status !== "Approved" && (
                            <button
                              type="button"
                              onClick={() => updateReviewStatus(r.id, "Approved")}
                              className="rounded-lg bg-emerald-400 px-3 py-1.5 text-xs font-semibold text-slate-950"
                            >
                              Approve
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => deleteReview(r.id)}
                            className="rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1.5 text-xs font-medium text-rose-300"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {adminTab === "pricing" && (
                  <div className="grid gap-4 rounded-2xl border border-white/10 bg-[#08152b] p-5 md:grid-cols-3">
                    {products.map((p) => (
                      <div key={p.id} className="rounded-xl border border-white/10 bg-[#050d1c] p-4">
                        <p className="text-sm font-bold text-white">{p.name}</p>
                        <label className="mt-3 block text-[11px] text-slate-400">
                          Illustrative Price Label
                        </label>
                        <input
                          type="text"
                          value={p.priceLabel}
                          onChange={(e) => updateProductPrice(p.id, e.target.value)}
                          className="mt-1 w-full rounded-lg border border-white/10 bg-[#08152b] px-3 py-1.5 text-xs text-white"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {adminTab === "settings" && (
                  <div className="grid gap-6 lg:grid-cols-12">
                    <div className="space-y-3 rounded-2xl border border-white/10 bg-[#08152b] p-5 lg:col-span-5">
                      <h3 className="text-sm font-bold text-white">Editable Contact &amp; Vision</h3>
                      <div>
                        <label className="block text-[11px] text-slate-400">Contact Email</label>
                        <input
                          type="text"
                          value={contactInfo.email}
                          onChange={(e) =>
                            setContactInfo({ ...contactInfo, email: e.target.value })
                          }
                          className="mt-1 w-full rounded-lg border border-white/10 bg-[#050d1c] px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400">Phone Label</label>
                        <input
                          type="text"
                          value={contactInfo.phone}
                          onChange={(e) =>
                            setContactInfo({ ...contactInfo, phone: e.target.value })
                          }
                          className="mt-1 w-full rounded-lg border border-white/10 bg-[#050d1c] px-3 py-2 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400">Brand Vision</label>
                        <textarea
                          rows="3"
                          value={visionStatement}
                          onChange={(e) => setVisionStatement(e.target.value)}
                          className="mt-1 w-full rounded-lg border border-white/10 bg-[#050d1c] px-3 py-2 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="rounded-2xl border border-white/10 bg-[#050d1c] p-5 lg:col-span-7">
                      <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                        <Database className="h-4 w-4" />
                        <span>Supabase PostgreSQL &amp; RLS Policy Blueprint</span>
                      </div>
                      <pre className="mt-3 max-h-80 overflow-auto rounded-xl bg-black/50 p-3.5 text-[11px] leading-relaxed text-slate-300">
                        <code>{SUPABASE_SQL_SCHEMA}</code>
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/10 bg-[#030812] py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col justify-between gap-6 border-b border-white/10 pb-8 md:flex-row md:items-center">
            <div>
              <AquaSenseLogo />
              <p className="mt-3 text-xs text-slate-400">
                &ldquo;Intelligence for Every Drop.&rdquo; • Smart Industrial Wastewater Management
                System Prototype by <strong className="text-slate-200">THE THINKERS</strong>.
              </p>
            </div>
            <div className="flex flex-wrap gap-4 text-xs text-slate-400">
              <span>Privacy Notice (Demo Placeholder)</span>
              <span>•</span>
              <span>Terms of Demonstration Use (Placeholder)</span>
              <span>•</span>
              <span>Not Certified for Potable or Discharge Compliance</span>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
            <span>AQUASENSE • An innovation by THE THINKERS.</span>
            <span>Illustrative pricing &amp; local demo mode active unless connected to backend.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
